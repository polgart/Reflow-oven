/* 
 * File:   baseSW.h
 * Author: EDU_OBOS_5057
 *
 * Created on February 18, 2021, 4:23 PM
 */

#ifndef BASESW_H
#define	BASESW_H

#include "stateTaskHandler.h"

#ifdef	__cplusplus
extern "C" {
#endif

stateTaskList* baseSW_Initialize(void);


#ifdef	__cplusplus
}
#endif

#endif	/* BASESW_H */

