/* 
 * File:   piclib30_wrapper.h
 * Author: EDU_OBOS_5057
 *
 * Created on February 21, 2021, 12:35 AM
 */

#ifndef PICLIB30_WRAPPER_H
#define	PICLIB30_WRAPPER_H

#ifdef	__cplusplus
extern "C" {
#endif

#define FCY 4000000UL
#include <libpic30.h>


#ifdef	__cplusplus
}
#endif

#endif	/* PICLIB30_WRAPPER_H */

